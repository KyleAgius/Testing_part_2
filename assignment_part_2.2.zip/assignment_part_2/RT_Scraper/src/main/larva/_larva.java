
package larva;

public class _larva {

public static void _finalize(){
 RunningClock.on = false;
 Channel.on = false;
}
}