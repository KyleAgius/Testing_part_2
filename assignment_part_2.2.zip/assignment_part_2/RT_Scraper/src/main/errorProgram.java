package main;


public class errorProgram {
	public static void main(String args[])
    {		
		EventLogQuery logs = new EventLogQuery();
		logs.ViewedAlerts();
			  
    }
}
